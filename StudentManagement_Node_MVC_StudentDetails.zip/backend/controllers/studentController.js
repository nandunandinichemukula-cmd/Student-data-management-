const Student = require("../models/studentModel");

async function getStudents(req, res) {
    try {
        const students = await Student.getAll();
        res.json(students);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Database error" });
    }
}

async function addStudent(req, res) {
    try {
        const { name, age } = req.body;

        if (!name || !age || Number(age) <= 0) {
            return res.status(400).json({
                message: "Enter a valid name and age."
            });
        }

        const id = await Student.create(name.trim(), Number(age));

        res.status(201).json({
            message: "Student added successfully.",
            id
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Database error" });
    }
}

async function updateStudent(req, res) {
    try {
        const { id } = req.params;
        const { name, age } = req.body;

        if (!name || !age || Number(age) <= 0) {
            return res.status(400).json({
                message: "Enter a valid name and age."
            });
        }

        const affected = await Student.update(
            id,
            name.trim(),
            Number(age)
        );

        if (!affected) {
            return res.status(404).json({
                message: "Student not found."
            });
        }

        res.json({ message: "Student updated successfully." });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Database error" });
    }
}

async function deleteStudent(req, res) {
    try {
        const affected = await Student.remove(req.params.id);

        if (!affected) {
            return res.status(404).json({
                message: "Student not found."
            });
        }

        res.json({ message: "Student deleted successfully." });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Database error" });
    }
}

module.exports = {
    getStudents,
    addStudent,
    updateStudent,
    deleteStudent
};
