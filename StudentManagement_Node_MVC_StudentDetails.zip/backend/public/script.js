const API = "/api/students";

const form = document.getElementById("studentForm");
const idInput = document.getElementById("studentId");
const nameInput = document.getElementById("name");
const ageInput = document.getElementById("age");
const table = document.getElementById("studentTable");
const message = document.getElementById("message");
const saveBtn = document.getElementById("saveBtn");
const cancelBtn = document.getElementById("cancelBtn");

// These appear immediately when the page opens.
let students = [
    { id: 1, name: "Nandini", age: 22 },
    { id: 2, name: "Rahul", age: 21 },
    { id: 3, name: "Priya", age: 20 }
];

function renderStudents(list) {
    table.innerHTML = "";

    if (!list.length) {
        table.innerHTML = `<tr><td colspan="4">No student details found.</td></tr>`;
        return;
    }

    list.forEach(student => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${student.id}</td>
            <td>${escapeHtml(student.name)}</td>
            <td>${student.age}</td>
            <td>
                <button onclick="editStudent(${student.id})">Edit</button>
                <button onclick="deleteStudent(${student.id})">Delete</button>
            </td>
        `;

        table.appendChild(row);
    });
}

async function loadStudents() {
    // Show student details immediately.
    renderStudents(students);

    try {
        const response = await fetch(API);

        if (!response.ok) throw new Error("API unavailable");

        const data = await response.json();

        // Use database records when the backend/database is available.
        if (Array.isArray(data) && data.length > 0) {
            students = data;
            renderStudents(students);
            message.textContent = "Student details loaded.";
        } else {
            message.textContent = "Showing sample student details.";
        }
    } catch (error) {
        // Keep the sample records visible instead of leaving the table empty.
        message.textContent =
            "Database is not connected. Showing sample student details.";
        renderStudents(students);
    }
}

form.addEventListener("submit", async event => {
    event.preventDefault();

    const id = idInput.value;

    const student = {
        name: nameInput.value.trim(),
        age: Number(ageInput.value)
    };

    if (!student.name || !student.age || student.age <= 0) {
        message.textContent = "Please enter a valid name and age.";
        return;
    }

    try {
        const response = await fetch(id ? `${API}/${id}` : API, {
            method: id ? "PUT" : "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(student)
        });

        const result = await response.json();

        if (!response.ok) throw new Error(result.message);

        message.textContent = result.message;
        resetForm();
        await loadStudents();

    } catch (error) {
        // Demo/local fallback so the UI still works without MySQL.
        if (id) {
            const index = students.findIndex(s => s.id == id);
            if (index !== -1) {
                students[index] = { id: Number(id), ...student };
            }
            message.textContent = "Student updated in demo mode.";
        } else {
            const nextId = students.length
                ? Math.max(...students.map(s => Number(s.id))) + 1
                : 1;

            students.push({
                id: nextId,
                name: student.name,
                age: student.age
            });

            message.textContent = "Student added in demo mode.";
        }

        resetForm();
        renderStudents(students);
    }
});

function editStudent(id) {
    const student = students.find(s => s.id == id);
    if (!student) return;

    idInput.value = student.id;
    nameInput.value = student.name;
    ageInput.value = student.age;

    saveBtn.textContent = "Update Student";
    cancelBtn.classList.remove("hidden");
    nameInput.focus();
}

cancelBtn.addEventListener("click", resetForm);

async function deleteStudent(id) {
    if (!confirm("Delete this student?")) return;

    try {
        const response = await fetch(`${API}/${id}`, {
            method: "DELETE"
        });

        const result = await response.json();

        if (!response.ok) throw new Error(result.message);

        message.textContent = result.message;
        await loadStudents();

    } catch (error) {
        students = students.filter(s => s.id != id);
        message.textContent = "Student deleted in demo mode.";
        renderStudents(students);
    }
}

function resetForm() {
    form.reset();
    idInput.value = "";
    saveBtn.textContent = "Add Student";
    cancelBtn.classList.add("hidden");
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

loadStudents();
