const express = require("express");
const controller = require("../controllers/studentController");

const router = express.Router();

router.get("/", controller.getStudents);
router.post("/", controller.addStudent);
router.put("/:id", controller.updateStudent);
router.delete("/:id", controller.deleteStudent);

module.exports = router;
