const db = require("../config/db");

async function getAll() {
    const [rows] = await db.query(
        "SELECT id, name, age FROM student ORDER BY id"
    );
    return rows;
}

async function create(name, age) {
    const [result] = await db.query(
        "INSERT INTO student (name, age) VALUES (?, ?)",
        [name, age]
    );
    return result.insertId;
}

async function update(id, name, age) {
    const [result] = await db.query(
        "UPDATE student SET name = ?, age = ? WHERE id = ?",
        [name, age, id]
    );
    return result.affectedRows;
}

async function remove(id) {
    const [result] = await db.query(
        "DELETE FROM student WHERE id = ?",
        [id]
    );
    return result.affectedRows;
}

module.exports = {
    getAll,
    create,
    update,
    remove
};
